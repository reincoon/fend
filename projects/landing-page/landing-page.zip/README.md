# Landing Page Project
This project is created in Vanilla JavaScript without any framework to practice the interaction with browser events.
## Table of Contents
*css
--style.css
*js
--app.js
*index.html
*readme

* [Instructions](#instructions)

## Instructions

The starter project was provided by Udacity: https://github.com/udacity/fend/tree/refresh-2019.

File `js/app.js` consists of self built app's functionality.


