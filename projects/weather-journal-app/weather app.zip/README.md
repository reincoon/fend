# Weather-Journal App Project

## Overview
This project is made to learn how to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
The `server.js` file and the `website/app.js` file were modified. `index.html` file and `style.css` were left without modifications as was provided by Udacity. 

## Extras
The project was cloned from repository https://github.com/udacity/fend/tree/refresh-2019.